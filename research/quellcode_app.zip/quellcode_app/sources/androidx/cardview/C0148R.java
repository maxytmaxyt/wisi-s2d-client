package androidx.cardview;

/* JADX INFO: renamed from: androidx.cardview.R */
/* JADX INFO: loaded from: classes.dex */
public final class C0148R {

    /* JADX INFO: renamed from: androidx.cardview.R$attr */
    public static final class attr {
        public static int cardBackgroundColor = 2130968763;
        public static int cardCornerRadius = 2130968764;
        public static int cardElevation = 2130968765;
        public static int cardMaxElevation = 2130968768;
        public static int cardPreventCornerOverlap = 2130968769;
        public static int cardUseCompatPadding = 2130968771;
        public static int cardViewStyle = 2130968772;
        public static int contentPadding = 2130968961;
        public static int contentPaddingBottom = 2130968962;
        public static int contentPaddingLeft = 2130968964;
        public static int contentPaddingRight = 2130968965;
        public static int contentPaddingTop = 2130968967;

        private attr() {
        }
    }

    /* JADX INFO: renamed from: androidx.cardview.R$color */
    public static final class color {
        public static int cardview_dark_background = 2131099713;
        public static int cardview_light_background = 2131099714;
        public static int cardview_shadow_end_color = 2131099715;
        public static int cardview_shadow_start_color = 2131099716;

        private color() {
        }
    }

    /* JADX INFO: renamed from: androidx.cardview.R$dimen */
    public static final class dimen {
        public static int cardview_compat_inset_shadow = 2131166035;
        public static int cardview_default_elevation = 2131166036;
        public static int cardview_default_radius = 2131166037;

        private dimen() {
        }
    }

    /* JADX INFO: renamed from: androidx.cardview.R$style */
    public static final class style {
        public static int Base_CardView = 2132082710;
        public static int CardView = 2132082984;
        public static int CardView_Dark = 2132082985;
        public static int CardView_Light = 2132082986;

        private style() {
        }
    }

    /* JADX INFO: renamed from: androidx.cardview.R$styleable */
    public static final class styleable {
        public static int[] CardView = {android.R.attr.minWidth, android.R.attr.minHeight, com.tivicon.tv2smart.mobile.R.attr.cardBackgroundColor, com.tivicon.tv2smart.mobile.R.attr.cardCornerRadius, com.tivicon.tv2smart.mobile.R.attr.cardElevation, com.tivicon.tv2smart.mobile.R.attr.cardMaxElevation, com.tivicon.tv2smart.mobile.R.attr.cardPreventCornerOverlap, com.tivicon.tv2smart.mobile.R.attr.cardUseCompatPadding, com.tivicon.tv2smart.mobile.R.attr.contentPadding, com.tivicon.tv2smart.mobile.R.attr.contentPaddingBottom, com.tivicon.tv2smart.mobile.R.attr.contentPaddingLeft, com.tivicon.tv2smart.mobile.R.attr.contentPaddingRight, com.tivicon.tv2smart.mobile.R.attr.contentPaddingTop};
        public static int CardView_android_minHeight = 1;
        public static int CardView_android_minWidth = 0;
        public static int CardView_cardBackgroundColor = 2;
        public static int CardView_cardCornerRadius = 3;
        public static int CardView_cardElevation = 4;
        public static int CardView_cardMaxElevation = 5;
        public static int CardView_cardPreventCornerOverlap = 6;
        public static int CardView_cardUseCompatPadding = 7;
        public static int CardView_contentPadding = 8;
        public static int CardView_contentPaddingBottom = 9;
        public static int CardView_contentPaddingLeft = 10;
        public static int CardView_contentPaddingRight = 11;
        public static int CardView_contentPaddingTop = 12;

        private styleable() {
        }
    }

    private C0148R() {
    }
}
